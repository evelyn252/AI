# ====================
# 模型的评价更新操作
# ====================

from game import State
from pv_mcts import pv_mcts_action
from tensorflow.python.keras.models import load_model
#import keras.backend.tensorflow_backend as K
from tensorflow.python.keras import backend as K
import tensorflow as tf
from pathlib import Path
from shutil import copy
import numpy as np

# 参数定义准备
EN_GAME_COUNT = 10 # 评价进行的局数
EN_TEMPERATURE = 1.0 


#判断先手是胜利还是失败，还是平局
def first_player_point(ended_state):
    # 1:先手胜利, 0:先手失败, 0.5:平局
    if ended_state.is_lose():
        return 0 if ended_state.is_first_player() else 1
    return 0.5


def play(next_actions):
    #状态生成
    state = State()

    while True:
        # 结束条件判定
        if state.is_done():
            break;

        # 行动权的判定获取
        next_action = next_actions[0] if state.is_first_player() else next_actions[1]
        action = next_action(state)

        # 下一状态的获取
        state = state.next(action)

    # 判断棋局状态并返回
    return first_player_point(state)

#模型的评定交换更新
def update_best_player():
    copy('./model/latest.h5', './model/best.h5')
    print('Change BestPlayer')

# 模型评定
def evaluate_network():
    K.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu':0})))
    # 最新训练出来的模型的load
    model0 = load_model('./model/latest.h5')

    # 上一个训练模型的load
    model1 = load_model('./model/best.h5')

    # 下一动作的选择
    next_action0 = pv_mcts_action(model0, EN_TEMPERATURE)
    next_action1 = pv_mcts_action(model1, EN_TEMPERATURE)
    next_actions = (next_action0, next_action1)

    # 对战EN_GAME_COUNT次，记录先手的得分情况
    total_point = 0
    for i in range(EN_GAME_COUNT):
        # 1ゲームの実行
        if i % 2 == 0:
            total_point += play(next_actions)
        else:
            total_point += 1 - play(list(reversed(next_actions)))

        # 出力
        print('\rEvaluate {}/{}'.format(i + 1, EN_GAME_COUNT), end='')
    print('')

    # 计算对战的平均得分
    average_point = total_point / EN_GAME_COUNT
    print('AveragePoint', average_point)

    
    K.clear_session()
    del model0
    del model1

    # 如果平均得分＞0.5，则用当前模型替换上一个训练的best.h5模型
    if average_point > 0.5:
        update_best_player()
        return True
    else:
        return False

# 动作确认
if __name__ == '__main__':
    evaluate_network()
