# ====================
# lasted model训练生成
# ====================

from dual_network import DN_INPUT_SHAPE
from tensorflow.python.keras.callbacks import LearningRateScheduler, LambdaCallback
from tensorflow.python.keras.models import load_model
#import keras.backend.tensorflow_backend as K
from tensorflow.python.keras import backend as K
from pathlib import Path
import numpy as np
import pickle
import tensorflow as tf
#import tensorflow as tf
import matplotlib.pyplot as plt
# 参数准备
RN_EPOCHS = 30 #训练次数

# 导入self_play生成的训练数据
def load_data():
    history_path = sorted(Path('./data').glob('*.history'))[-1]
    with history_path.open(mode='rb') as f:
        return pickle.load(f)


def train_network():
    # 检测是否可以使用GPU
    K.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu':0})))
    
    history = load_data()
    xs, y_policies, y_values = zip(*history)

    # 输入数据的shape转成我们需要的格式
    a, b, c = DN_INPUT_SHAPE
    xs = np.array(xs)
    xs = xs.reshape(len(xs), c, a, b).transpose(0, 2, 3, 1)
    y_policies = np.array(y_policies)
    y_values = np.array(y_values)

    # 导入当前我们的best model模型
    model = load_model('./model/best.h5')

    # loss 和优化器的选取
    model.compile(loss=['categorical_crossentropy', 'mse'], optimizer='adam')
    #model.compile(loss='categorical_crossentropy', optimizer='adam')
    #学习率分段设置，可以使得loss更快收敛
    def step_decay(epoch):
        x = 0.001
        if epoch >= 50: x = 0.0005
        if epoch >= 80: x = 0.00025
        return x
    lr_decay = LearningRateScheduler(step_decay)

    
    print_callback = LambdaCallback(
        on_epoch_begin=lambda epoch,logs:
                print('\rTrain {}/{}'.format(epoch + 1,RN_EPOCHS), end=''))

    # 模型训练
    hist=model.fit(xs, [y_policies, y_values], batch_size=128, epochs=RN_EPOCHS,
            verbose=0, callbacks=[lr_decay, print_callback])
    
    #loss图示
    print('')
    fig=plt.figure()
    ax1=fig.add_subplot(111)
    ax1.plot(hist.history['loss'],'blue',label='val_loss')
    #ax1.plot(hist.history['loss'],'red',label='val_mse')
    #ax1.plot(history_mean_drop['pearson'],'green',label='Mean Pooling with Drop out')
    ax1.legend(loc='best')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('mse')
    ax1.set_title('Training mse')
   # fig.savefig('mse1.png')
    
    # 保存最新训练生成的model
    model.save('./model/latest.h5')

    
    K.clear_session()
    del model

#开始训练
if __name__ == '__main__':
    train_network()
