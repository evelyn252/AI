# ====================
# 训练数据的生成
# ====================

from game import State
from pv_mcts import pv_mcts_scores
from dual_network import DN_OUTPUT_SIZE
from datetime import datetime
from tensorflow.python.keras.models import load_model
#import keras.backend.tensorflow_backend as K
from tensorflow.python.keras import backend as K
from pathlib import Path
import numpy as np
import pickle
import os
import tensorflow as tf

#K.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu':0})))
# 
SP_GAME_COUNT = 100 # 对战次数
SP_TEMPERATURE = 1.0 #概率分布控制的一个参数，这里选为1


def first_player_value(ended_state):
    # 1:先手胜利，-1：先手失败，0：平局
    if ended_state.is_lose():
        return -1 if ended_state.is_first_player() else 1
    return 0

# 训练数据的保存
def write_data(history):
    now = datetime.now()
    os.makedirs('./data/', exist_ok=True) #文件夹的生成
    path = './data/{:04}{:02}{:02}{:02}{:02}{:02}.history'.format(
        now.year, now.month, now.day, now.hour, now.minute, now.second)
    with open(path, mode='wb') as f:
        pickle.dump(history, f)


def play(model):
   #训练数据将会保存在history中
    history = []

    #初始状态的生成
    state = State()

    while True:
        # 游戏结束
        if state.is_done():
            break

        # 合法位置概率分布
        scores = pv_mcts_scores(model, state, SP_TEMPERATURE)

        # 学习数据加入history中
        policies = [0] * DN_OUTPUT_SIZE
        for action, policy in zip(state.legal_actions(), scores):
            policies[action] = policy
        history.append([[state.pieces, state.enemy_pieces], policies, None])

        # 行动的获取
        action = np.random.choice(state.legal_actions(), p=scores)

        # 下一个状态的获取
        state = state.next(action)

    #history相关数据的追加，将会被当作标签
    value = first_player_value(state)
    for i in range(len(history)):
        history[i][2] = value
        value = -value
    return history


def self_play():
    
    history = []

    #导入当前最好的模型
    model = load_model('./model/best.h5')

    # 自我对战次数
    for i in range(SP_GAME_COUNT):
        h = play(model)
        history.extend(h)
        print('\rSelfPlay {}/{}'.format(i+1, SP_GAME_COUNT), end='')
    print('')

    #数据保存，方便用于训练
    write_data(history)

    # 会话清除
    K.clear_session()
    del model


if __name__ == '__main__':
    self_play()
