# ====================
#网络的搭建，用残差神经网络
#不难理解，但是这个敌方有dqn吗？显然，木有！
# ====================

from tensorflow.python.keras.layers import Activation, Add, BatchNormalization, Conv2D, Dense, GlobalAveragePooling2D, Input
from tensorflow.python.keras.models import Model
from tensorflow.python.keras.regularizers import l2
#from tensorflow.python.keras import backend as K
#import keras.backend.tensorflow_backend as K
from tensorflow.python.keras import backend as K
import os
import tensorflow as tf
#import copy
#import tensorflow.python as tf
#Conv2D是卷积操作


DN_FILTERS  = 128 
DN_RESIDUAL_NUM =  16 # 残差网络层数
DN_INPUT_SHAPE = (8, 8, 2) #输入的张量格式
DN_OUTPUT_SIZE = 65 #行动数

#卷积操作定义
def conv(filters):
    return Conv2D(filters, 3, padding='same', use_bias=False,
        kernel_initializer='he_normal', kernel_regularizer=l2(0.0005))

#残差网络单元定义，里面有两个卷积操作
def residual_block():
    def f(x):
        sc = x
        x = conv(DN_FILTERS)(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
        x = conv(DN_FILTERS)(x)
        x = BatchNormalization()(x)
        x = Add()([x, sc])
        x = Activation('relu')(x)
        return x
    return f

# 网络搭建
def dual_network():
    #如果model存在，就直接读取使用
    #否则就自己训练出来一个model来用
    K.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu':0})))
    if os.path.exists('./model/best.h5'):
        return

    #输入变成张量
    input = Input(shape=DN_INPUT_SHAPE)

   
    
    #先进行一次卷积操作
    x = conv(DN_FILTERS)(input)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)

   
    #残差网络开始构建
    for i in range(DN_RESIDUAL_NUM):
        x = residual_block()(x)

   
    #池化操作
    x = GlobalAveragePooling2D()(x)

    #线性操作+激活函数
    p = Dense(DN_OUTPUT_SIZE, kernel_regularizer=l2(0.0005),
                activation='softmax', name='pi')(x)
    

    v = Dense(1, kernel_regularizer=l2(0.0005))(x)
    v = Activation('tanh', name='v')(v)

    
    #模型建立
    model = Model(inputs=input, outputs=[p,v])
    

    #模型的生成存放
    os.makedirs('./model/', exist_ok=True) # 生成文件夹
    model.save('./model/best.h5') # 保存当前模型为best.h5

    #清空会话产生的记录，不清除的话会在训练时产生错误，找不到自己想要的特征的记录
    K.clear_session()
    del model

# 動作確認
if __name__ == '__main__':
    dual_network()
