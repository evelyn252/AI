# ====================
# 模型的训练
# ====================

from dual_network import dual_network
from self_play import self_play
from train_network import train_network
from evaluate_network import evaluate_network
import os
import tensorflow as tf
#import keras.backend.tensorflow_backend as K
#from tensorflow.keras import backend as K
from tensorflow.python.keras import backend as K


dual_network()
#检测是否可以使用GPU
K.set_session(tf.Session(config=tf.ConfigProto(device_count={'gpu':0})))


for i in range(1):
    print('Train',i,'====================')
    # 训练数据生成
    self_play()

    # lasted model的训练生成
    train_network()

    # 模型评估
    evaluate_network()

    K.clear_session()