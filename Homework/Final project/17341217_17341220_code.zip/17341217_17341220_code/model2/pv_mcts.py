# ====================
# mcts搜索方法的应用
# ====================

from game import State
from dual_network import DN_INPUT_SHAPE
from math import sqrt
from tensorflow.python.keras.models import load_model
from pathlib import Path
import numpy as np


#评价次数，对战的次数
PV_EVALUATE_COUNT = 50 

# 预测函数的定义编写
def predict(model, state):
    
    #对游戏状态，数据输入格式的调整
    a, b, c = DN_INPUT_SHAPE
    x = np.array([state.pieces, state.enemy_pieces],dtype=np.float)
    x = x.reshape(c, a, b).transpose(1, 2, 0).reshape(1, a, b, c)

    # 根据网络预测出y值
    y = model.predict(x, batch_size=1)
    
   
    # 策略的获取
    #合法位置的获取
    policies = y[0][0][list(state.legal_actions())] 
    
    policies /= sum(policies) if sum(policies) else 1 # 合法位置概率分布的确定
    #print("the policies is ",policies)

    #这个value是通过激活函数dense操作，求得的
    #对应的位置的value值的获取
    value = y[1][0][0]
    return policies, value



#求每个节点的分数，并以列表的形式返回
def nodes_to_scores(nodes):
    scores = []
    for c in nodes:
        scores.append(c.n)
    return scores

# 最佳行动策略的探索获取
def pv_mcts_scores(model, state, temperature):
    # 定义Node,方便状态，分数，子节点等变量之间建立联系
    class Node:
        # 初始化
        def __init__(self, state, p):
            self.state = state # 状态
            self.p = p # 策略
            self.w = 0 # 累计分数
            self.n = 0 
            self.child_nodes = None  # 子节点

        # 棋局分数的计算
        def evaluate(self):
            # 结束状态的判定
            if self.state.is_done():
                # 胜负结果
                value = -1 if self.state.is_lose() else 0

                # 累计分数更新，行动次数也相应更新
                self.w += value
                self.n += 1
                return value

            # 如果当前节点不存在子节点
            if not self.child_nodes:
                # 获取当前状态的策略的概率分布和对应的value值
                policies, value = predict(model, self.state)

                # 累计分数更新，行动次数也相应更新
                self.w += value
                self.n += 1

                # 添加子节点
                self.child_nodes = []
                for action, policy in zip(self.state.legal_actions(), policies):
                    self.child_nodes.append(Node(self.state.next(action), policy))
                #返回value值
                return value

            # 如果当前节点存在子节点
            else:
                # 评价值最大的子节点的value值的获取
                value = -self.next_child_node().evaluate()

                # 累计分数更新，行动次数也相应更新
                self.w += value
                self.n += 1
                return value

        # 评价值最大子节点的获取
        def next_child_node(self):
            # 按照公式进行计算
            #C_PUCT = 1.0
            C_PUCT = 1.0
            t = sum(nodes_to_scores(self.child_nodes))
            pucb_values = []
            for child_node in self.child_nodes:
                pucb_values.append((-child_node.w / child_node.n if child_node.n else 0.0) +
                    C_PUCT * child_node.p * sqrt(t) / (1 + child_node.n))

            
            #np.argmax()选取最大元素对应的索引
            #找到最大的子节点之后返回
            return self.child_nodes[np.argmax(pucb_values)]

    # 父节点初始化
    root_node = Node(state, 0)

    #
    for _ in range(PV_EVALUATE_COUNT):
        root_node.evaluate()

    # 合法位置概率分布确定
    scores = nodes_to_scores(root_node.child_nodes)
    if temperature == 0: # 最大值为1
        action = np.argmax(scores)
        scores = np.zeros(len(scores))
        scores[action] = 1
    else: 
        scores = boltzman(scores, temperature)
    return scores


def pv_mcts_action(model, temperature=0):
    def pv_mcts_action(state):
        scores = pv_mcts_scores(model, state, temperature)
        return np.random.choice(state.legal_actions(), p=scores)
    return pv_mcts_action


def boltzman(xs, temperature):
    xs = [x ** (1 / temperature) for x in xs]
    return [x / sum(xs) for x in xs]


if __name__ == '__main__':
    path = sorted(Path('./model').glob('*.h5'))[-1]
    model = load_model(str(path))

    state = State()

   #下一个动作的选取
    next_action = pv_mcts_action(model, 1.0)

 
    while True:
        #判断结束状态
        if state.is_done():
            break

        #下一个动作的选取和下一个状态的确定
        action = next_action(state)
        state = state.next(action)


        print(state)