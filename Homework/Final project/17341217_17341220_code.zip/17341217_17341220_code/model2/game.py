# ====================
# 游戏相关参数的确定
# ====================
import random
import math

# 定义State类
class State:
    # 初始化
    def __init__(self, pieces=None, enemy_pieces=None, depth=0):
        # 八个方向
        self.dxy = ((1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1))

        # 用来判断游戏是否终止
        self.pass_end = False

        # 棋子分配
        self.pieces = pieces#己方棋子
        self.enemy_pieces = enemy_pieces#敌方棋子
        self.depth = depth

        #初始化棋局四个棋子的设置
        if pieces == None or enemy_pieces == None:
            self.pieces = [0] * 64
            self.pieces[27] = self.pieces[36] = 1
            self.enemy_pieces = [0] * 64
            self.enemy_pieces[28] = self.enemy_pieces[35] = 1

    #最终棋子数的获得，用来判定输和赢
    def piece_count(self, pieces):
        count = 0
        for i in pieces:
            if i == 1:
                count +=  1
        return count

    # 输的情况判断
    def is_lose(self):
        return self.is_done() and self.piece_count(self.pieces) < self.piece_count(self.enemy_pieces)

    # 平局的情况判断
    def is_draw(self):
        return self.is_done() and self.piece_count(self.pieces) == self.piece_count(self.enemy_pieces)

    # 棋局结束的情况判断
    def is_done(self):
        return self.piece_count(self.pieces) + self.piece_count(self.enemy_pieces) == 64 or self.pass_end

    # 下一个状态的获取
    def next(self, action):
        #action其中的一个合法的可落子的位置
        state = State(self.pieces.copy(), self.enemy_pieces.copy(), self.depth+1)
        if action != 64:
            state.is_legal_action_xy(action%8, int(action/8), True)
            
        #敌我双发交换阵营
        w = state.pieces
        state.pieces = state.enemy_pieces
        state.enemy_pieces = w

        #结束状态的确定
        if action == 64 and state.legal_actions() == [64]:
            state.pass_end = True
        return state

    # 合法位置的获取，在获取合法位置的同时翻转可以翻转的所有棋子，同时把该合法位置压入列表
    def legal_actions(self):
        actions = []
        for j in range(0,8):
            for i in range(0,8):
                if self.is_legal_action_xy(i, j):
                    actions.append(i+j*8)
        if len(actions) == 0:
            actions.append(64) #如果没有合法位置，就压入64，所以一共有65种状态
        return actions

    # 判断位置是否是合法位置
    def is_legal_action_xy(self, x, y, flip=False):
        def is_legal_action_xy_dxy(x, y, dx, dy):
            #位置是否合法的一个判断
            #当前位置朝一个方向移动之后，判断该位置是否有敌方棋子，如果没有，返回false
            #如果有，接着进行其他操作，最基本的判断，移动后的坐标要合法
            x, y = x+dx, y+dy
            if y < 0 or 7 < y or x < 0 or 7 < x or \
                self.enemy_pieces[x+y*8] != 1:
                return False


            #每个方向都要检查到边缘的所有棋子
            for j in range(8):
                #如果当前位置上合法且没有敌方棋子和己方棋子，返回false。
                if y < 0 or 7 < y or x < 0 or 7 < x or \
                    (self.enemy_pieces[x+y*8] == 0 and self.pieces[x+y*8] == 0):
                    return False

                
                #如果当前位置上有己方棋子，则要判断是否可以翻转
                if self.pieces[x+y*8] == 1:
                    # 如果可以翻转，把所有的可以翻转的棋子都翻转了，然后返回true
                    if flip:
                        for i in range(8):
                            x, y = x-dx, y-dy
                            if self.pieces[x+y*8] == 1:
                                return True
                            self.pieces[x+y*8] = 1
                            self.enemy_pieces[x+y*8] = 0
                    #该位置如果不能翻转
                    return True
                # 该方向的下一个棋子
                x, y = x+dx, y+dy
            return False

        # 如果该位置非空，则直接返回false
        if self.enemy_pieces[x+y*8] == 1 or self.pieces[x+y*8] == 1:
            return False

        
        #如果该位置可翻转，该位置落子
        if flip:
            self.pieces[x+y*8] = 1

        
        #位置合法之后翻转操作
        flag = False
        for dx, dy in self.dxy:
            if is_legal_action_xy_dxy(x, y, dx, dy):
                flag = True
        return flag


    #判断是否为先手
    def is_first_player(self):
        return self.depth%2 == 0

    #画图，画出整个棋盘
    def __str__(self):
        ox = ('o', 'x') if self.is_first_player() else ('x', 'o')
        str = ''
        for i in range(64):
            if self.pieces[i] == 1:
                str += ox[0]
            elif self.enemy_pieces[i] == 1:
                str += ox[1]
            else:
                str += '-'
            if i % 8 == 7:
                str += '\n'
        return str


#随机选取 一个合法的状态
def random_action(state):
    legal_actions = state.legal_actions()
    return legal_actions[random.randint(0, len(legal_actions)-1)]

