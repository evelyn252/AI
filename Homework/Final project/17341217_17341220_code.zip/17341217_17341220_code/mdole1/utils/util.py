from copy import deepcopy

from Valid import valid


def move(board, x, y, player, copy=False):
    '''
    :param board:8x8 matrix
    :param x,y：下棋的位置
    :param player: 0(black) or 1(white)
    :param copy:是否要深拷贝
    '''    
    if copy:
        m = deepcopy(board)
    else:
        m = board
    m.matrix[x][y] = player
    m.chess_cnt = m.chess_cnt + 1
    valid.eat(m.matrix, x, y)
    return m


def dumb_score(array, player):
    """
    :param array: 8x8 matrix
    :param player: 0(black) or 1(white)
    :return: 当前棋盘上己方的棋子数减去对手棋子数
    """
    score = 0
    color = player
    opponent = 1 - player

    for x in range(8):
        for y in range(8):
            if array[x][y] == color:
                score += 1
            elif array[x][y] == opponent:
                score -= 1
    return score
