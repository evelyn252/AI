下载整个文件夹后，运行main函数即可。
其中Model是模型实现；
View是可视化视图层实现；
Controller是控制层实现；
utils是初始化一些超参数；
valid是一些判定棋盘局面结束以及可行落子点的函数；

