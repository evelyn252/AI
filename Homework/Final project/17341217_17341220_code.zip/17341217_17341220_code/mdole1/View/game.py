def on_canvas_click(event, controller):
    controller.on_click(event)
    pass
