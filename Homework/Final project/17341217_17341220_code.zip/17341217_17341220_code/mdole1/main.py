from tkinter import *
from game import start_game

if __name__ == "__main__":
    root = Tk()   #创建窗口
    btn1 = Button(root, text='Player first', command=lambda: start_game(root, 0)).pack()  #按钮
    btn2 = Button(root, text='AI first', command=lambda: start_game(root, 1)).pack()  #按钮
    root.wm_title("Reversi Master")
    root.mainloop()
